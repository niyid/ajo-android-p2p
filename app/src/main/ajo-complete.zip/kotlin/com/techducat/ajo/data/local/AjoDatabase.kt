package com.techducat.ajo.data.local

import com.techducat.ajo.data.local.entity.ContributionEntity
import com.techducat.ajo.data.local.entity.ServiceFeeEntity
import com.techducat.ajo.data.local.entity.MemberEntity
import com.techducat.ajo.data.local.entity.RoscaEntity
import com.techducat.ajo.data.local.entity.PayoutEntity
import com.techducat.ajo.data.local.entity.PenaltyEntity
import com.techducat.ajo.data.local.entity.TransactionEntity
import com.techducat.ajo.data.local.entity.UserProfileEntity
import com.techducat.ajo.data.local.entity.InviteEntity
import com.techducat.ajo.data.local.entity.BidEntity
import com.techducat.ajo.data.local.entity.DividendEntity
import com.techducat.ajo.data.local.entity.RoundEntity
import com.techducat.ajo.data.local.entity.DistributionEntity
import com.techducat.ajo.data.local.entity.MultisigSignatureEntity

import com.techducat.ajo.data.local.dao.ContributionDao
import com.techducat.ajo.data.local.dao.ServiceFeeDao
import com.techducat.ajo.data.local.dao.MemberDao
import com.techducat.ajo.data.local.dao.RoscaDao
import com.techducat.ajo.data.local.dao.PayoutDao
import com.techducat.ajo.data.local.dao.PenaltyDao
import com.techducat.ajo.data.local.dao.TransactionDao
import com.techducat.ajo.data.local.dao.UserProfileDao
import com.techducat.ajo.data.local.dao.InviteDao
import com.techducat.ajo.data.local.dao.BidDao
import com.techducat.ajo.data.local.dao.DividendDao
import com.techducat.ajo.data.local.dao.RoundDao
import com.techducat.ajo.data.local.dao.DistributionDao
import com.techducat.ajo.data.local.dao.MultisigSignatureDao

import android.content.Context
import androidx.room.Room
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ============= Entities =============

@Entity(tableName = "sync_queue")
data class SyncQueueEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entityType: String,
    val entityId: String,
    val operation: String,
    val payload: String,
    val attempts: Int = 0,
    val maxAttempts: Int = 5,
    val createdAt: Long,
    val lastAttemptAt: Long?
)

// ============= DAOs =============
@Dao
interface SyncQueueDao {
    @Query("SELECT * FROM sync_queue WHERE attempts < maxAttempts ORDER BY createdAt ASC")
    suspend fun getPendingSyncs(): List<SyncQueueEntity>
    
    @Insert
    suspend fun insert(syncItem: SyncQueueEntity)
    
    @Delete
    suspend fun delete(syncItem: SyncQueueEntity)
}

// ============= Database =============

@Database(
    entities = [
        RoscaEntity::class,
        MemberEntity::class,
        ContributionEntity::class,
        RoundEntity::class,
        BidEntity::class,
        DividendEntity::class,
        DistributionEntity::class,
        ServiceFeeEntity::class,
        SyncQueueEntity::class,
        UserProfileEntity::class,
        PayoutEntity::class,
        PenaltyEntity::class,
        TransactionEntity::class,
        InviteEntity::class,
        MultisigSignatureEntity::class  // ← ADD THIS
    ],
    version = 9,
    exportSchema = false
)
@TypeConverters(DatabaseConverters::class)
abstract class AjoDatabase : RoomDatabase() {
    abstract fun roscaDao(): RoscaDao
    abstract fun contributionDao(): ContributionDao
    abstract fun memberDao(): MemberDao
    abstract fun distributionDao(): DistributionDao
    abstract fun serviceFeeDao(): ServiceFeeDao
    abstract fun syncQueueDao(): SyncQueueDao
    abstract fun userProfileDao(): UserProfileDao
    abstract fun payoutDao(): PayoutDao
    abstract fun penaltyDao(): PenaltyDao
    abstract fun transactionDao(): TransactionDao
    abstract fun inviteDao(): InviteDao
    abstract fun roundDao(): RoundDao
    abstract fun bidDao(): BidDao
    abstract fun dividendDao(): DividendDao
    abstract fun multisigSignatureDao(): MultisigSignatureDao
    
    companion object {
        @Volatile
        private var INSTANCE: AjoDatabase? = null
        
        fun getInstance(context: Context): AjoDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AjoDatabase::class.java,
                    "ajo_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
        
        fun clearDatabase(context: Context) {
            synchronized(this) {
                INSTANCE?.close()
                context.deleteDatabase("ajo_database")
                INSTANCE = null
            }
        }
        
        fun resetInstance() {
            INSTANCE?.close()
            INSTANCE = null
        }
    }
}
